/* Auto-generated config file enc28j60_spiif_config.h */
#ifndef ENC28J60_SPIIF_CONFIG_H
#define ENC28J60_SPIIF_CONFIG_H

// <<< Use Configuration Wizard in Context Menu >>>

// <<< end of configuration section >>>

#endif // ENC28J60_SPIIF_CONFIG_H
