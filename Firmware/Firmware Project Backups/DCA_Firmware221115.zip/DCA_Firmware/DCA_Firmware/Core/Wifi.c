/** INCLUDES ******************************************************************/
#include <string.h>
#include <stdlib.h>
#include "driver_init.h"
//#include "socket/include/socket.h"
#include "Wifi.h"