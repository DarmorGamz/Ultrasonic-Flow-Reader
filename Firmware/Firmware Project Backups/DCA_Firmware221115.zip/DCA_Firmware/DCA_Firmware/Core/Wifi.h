#ifndef WIFI_H_
#define WIFI_H_

#ifdef __cplusplus
extern "C" {
#endif
	
/** INCLUDES ******************************************************************/
#include <compiler.h>


/** CONSTANT AND MACRO DEFINITIONS *******************************************/


/** PUBLIC FUNCTION PROTOTYPES ************************************************/


#ifdef __cplusplus
}
#endif

#endif
