#ifndef SENSOR_H_
#define SENSOR_H_

#ifdef __cplusplus
extern "C" {
#endif
	
/** INCLUDES ******************************************************************/
#include <compiler.h>

/** PUBLIC FUNCTION PROTOTYPES ************************************************/
int8_t Sensor_Init(void);

#ifdef __cplusplus
}
#endif

#endif
