#include <atmel_start.h>

int main(void) {
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		gpio_set_pin_direction(LED_RED, GPIO_DIRECTION_OUT);
		gpio_set_pin_level(LED_RED, true);
	}
}
