/** INCLUDES ******************************************************************/
#include "driver_init.h"
#include <string.h>
#include "tcpip_lite_start.h"
#include "ipv4.h"
#include "Ethernet.h"
#include <App/DcaApp.h>

#define EYEDRO_OUI_BYTE_1                           0x60
#define EYEDRO_OUI_BYTE_2                           0x54
#define EYEDRO_OUI_BYTE_3                           0x64

// DNS resolution callback function pointer
typedef void (*dns_function_ptr)(void);

// DNS lookup state
typedef enum
{
	DNS_STATE_IDLE = 0,     // Ready to process DNS requests
	DNS_STATE_START,        // Initial state to reset client state variables
	DNS_STATE_OPEN_SOCKET,  // Open UDP socket
	DNS_STATE_QUERY,        // Send DNS query to DNS server
	DNS_STATE_GET_RESULT,   // Wait for response from DNS server
	DNS_STATE_FAIL,         // DNS server not responding
	DNS_STATE_DONE          // DNS query is finished
} eDnsState;

// Structure for the DNS header
typedef struct
{
	uint16_t u16TransactionID;
	uint16_t u16Flags;
	uint16_t u16Questions;
	uint16_t u16Answers;
	uint16_t u16AuthoritativeRecords;
	uint16_t u16AdditionalRecords;
} tsDnsHeader;

/** VARIABLES *****************************************************************/
static uint16_t         TIMER_ETH_SERVER_LOST_COMM;
static uint16_t         TIMER_ETH_SERVER_ESTABLISH_COMM;
static uint16_t         TIMER_ETH_CONNECION_TIMEOUT;
static uint16_t         TIMER_ETH_DNS_TIMEOUT;
static uint16_t         TIMER_ETH_DNS_REMOTE_RESOLUTION_TIMEOUT;
static uint16_t         TIMER_ETH_SOCKET_REMOTE_INIT_TIMEOUT;
static uint16_t         TIMER_ETH_SOCKET_REMOTE_RESPONSE_TIMEOUT;
static uint16_t         TIMER_ETH_SOCKET_REMOTE_CLEANUP_TIMEOUT;

static sEthernetInfo    s_stEthernetInfo;
static bool             s_fEthernetFirstTime = true;
static bool             s_fEthernetQueueServerSend = false;
static bool             s_fEthernetServerCommEstablished = false;
static bool             s_fEthernetServerCommLost = false;
static bool             s_fEthernetDisableLocalWebsvr = false;
//static bool             s_fDhcpDisabled = false;
//static bool             s_fUseStaticIPConf = false;

static uint8_t          s_u8EthernetHostIdx = 0; // alt1, alt2, primary, failsafe {repeat}

static uint16_t         s_u16EthernetPostLengthOffset = 0;
static uint16_t         s_u16EthernetPostPayloadOffset = 0;
static char             s_acEthernetStrPostHeader[HTTP_POST_HDR_BYTES];

static bool             s_fEthernetSocketsInitialized = false;
static tcpTCB_t         s_stEthernetSocketLocal;
static tcpTCB_t         s_stEthernetSocketRemote;
static sockaddr_in_t    s_stEthernetSocketAddressRemote;
static void             *s_pvEthernetRemainingLocalBuffer = NULL;
static uint16_t         s_u16EthernetRemainingLocalBytes = 0;
static void             *s_pvEthernetRemainingRemoteBuffer = NULL;
static uint16_t         s_u16EthernetRemainingRemoteBytes = 0;


static uint32_t         s_u32EthernetRemoteHostIp = 0;
static uint8_t          s_u8EthernetRemoteDnsAttempts = 0; // Will loop through host and failsafe a couple times before failing
static eDnsState        s_eEthernetDnsState = DNS_STATE_IDLE;


/** LOCAL (PRIVATE) FUNCTION PROTOTYPES ***************************************/
bool _DetectEthernet(void);

/** PUBLIC FUNCTION IMPLEMENTATIONS *******************************************/
bool Ethernet_Detect(void) {
	// Remove device from reset
    gpio_set_pin_level(ETHERNET_RESET, true);
    delay_ms(1);
    // Detect the device
    return _DetectEthernet();
}

int8_t Ethernet_Init(void) {
	// First determine if the Ethernet device exists
    bool fHasEthernet = Ethernet_Detect();
    if (fHasEthernet==false) return -1;
	
	// Allocate required resources first time only
    if (s_fEthernetFirstTime==true) {
        s_fEthernetFirstTime = false;

        // Create any timers required by the Ethernet - nothing to go wrong (assuming TIMER_MAX_COUNT is appropriate) so intentionally ignoring return value
        Timer_AddTimer(&TIMER_ETH_CONNECION_TIMEOUT);
        Timer_AddTimer(&TIMER_ETH_DNS_TIMEOUT);
        Timer_AddTimer(&TIMER_ETH_SERVER_LOST_COMM);
        Timer_AddTimer(&TIMER_ETH_SERVER_ESTABLISH_COMM);
        Timer_AddTimer(&TIMER_ETH_DNS_REMOTE_RESOLUTION_TIMEOUT);
        Timer_AddTimer(&TIMER_ETH_SOCKET_REMOTE_INIT_TIMEOUT);
        Timer_AddTimer(&TIMER_ETH_SOCKET_REMOTE_RESPONSE_TIMEOUT);
        Timer_AddTimer(&TIMER_ETH_SOCKET_REMOTE_CLEANUP_TIMEOUT);

    // Otherwise, just reset them
    } else {
        Timer_SetTimer(TIMER_ETH_CONNECION_TIMEOUT, 0);
        Timer_SetTimer(TIMER_ETH_DNS_TIMEOUT, 0);
        Timer_SetTimer(TIMER_ETH_SERVER_LOST_COMM, 0);
        Timer_SetTimer(TIMER_ETH_SERVER_ESTABLISH_COMM, 0);
        Timer_SetTimer(TIMER_ETH_DNS_REMOTE_RESOLUTION_TIMEOUT, 0);
        Timer_SetTimer(TIMER_ETH_SOCKET_REMOTE_INIT_TIMEOUT, 0);
        Timer_SetTimer(TIMER_ETH_SOCKET_REMOTE_RESPONSE_TIMEOUT, 0);
        Timer_SetTimer(TIMER_ETH_SOCKET_REMOTE_CLEANUP_TIMEOUT, 0);
    }

    // Initialize the Ethernet info structure
    memset((uint8_t *)&s_stEthernetInfo, 0, sizeof(sEthernetInfo));

    // Build the host name before initializing the stack (so the initial DHCP request will have the correct name)
    char acHostname[24];
    // Build the Hostname "EYEDRO-{SN}"
    sprintf(acHostname, "DCA-00001");
    uint8_t len = (uint8_t)strlen(acHostname)+1;

    // Build the MAC address (from OUI and serial) and set on ENC28J60 (defaults to 00DEAD00BEEF during init)
    // SN: xyz-abcde == MAC: 60:54:64:xy:zc:de
    g_au8MacAddress[0] = EYEDRO_OUI_BYTE_1; // 0x60
    g_au8MacAddress[1] = EYEDRO_OUI_BYTE_2; // 0x54
    g_au8MacAddress[2] = EYEDRO_OUI_BYTE_3; // 0x64
    g_au8MacAddress[3] = 0x00;
    g_au8MacAddress[4] =  0x10;
    g_au8MacAddress[5] = 0x01;


    //ETH_SetMAC(&g_au8MacAddress[0]);
    //ETH_InitMAC((uint8_t*)&g_au8MacAddress[0]);

    // Initialize TCP/IP Lite stack
    tcpip_lite_stack_init();
	
	return 0;
}


void Ethernet_PowerDown(void) {
	struct io_descriptor *s_ioSPI;
	uint8_t tx_buffer[2];

	// Get the IO descriptor for the SPI peripheral
	if (spi_m_sync_get_io_descriptor(&ETHERNET_SPI, &s_ioSPI)!=0 ) {
		return;
	};

	// Select register bank 3 (write control register 0x1F)
	// Prepare payload
	tx_buffer[0] = 0xA0|0x1F;   // Bit field clear | ECON1 register address
	tx_buffer[1] = 0x03;        // Bank 3
	// Enable the SPI slave (activates CSn)
	gpio_set_pin_level(ETHERNET_CS, 0);
	// Write payload
	io_write(s_ioSPI, tx_buffer, 2);
	// Disable the SPI slave (deactivates CSn)
	gpio_set_pin_level(ETHERNET_CS, 1);
	// Prepare payload
	tx_buffer[0] = 0x80|0x1F;   // Bit field set | ECON1 register address
	tx_buffer[1] = 0x03;        // Bank 3
	// Enable the SPI slave (activates CSn)
	gpio_set_pin_level(ETHERNET_CS, 0);
	// Write payload
	io_write(s_ioSPI, tx_buffer, 2);
	// Disable the SPI slave (deactivates CSn)
	gpio_set_pin_level(ETHERNET_CS, 1);

	// Prepare payload to put device in power saver mode
	tx_buffer[0] = 0x80|0x1E;   // Bit field set | ECON2 register address
	tx_buffer[1] = 0x20;        // PWRSV bit set
	// Enable the SPI slave (activates CSn)
	gpio_set_pin_level(ETHERNET_CS, 0);
	// Write payload
	io_write(s_ioSPI, tx_buffer, 2);
	// Disable the SPI slave (deactivates CSn)
	gpio_set_pin_level(ETHERNET_CS, 1);

	// Disable the SPI peripheral
	spi_m_sync_disable(&ETHERNET_SPI);
}

void Ethernet_PowerUp(void) {
	struct io_descriptor *s_ioSPI;
    uint8_t tx_buffer[2];

    // Enable the SPI peripheral
    spi_m_sync_enable(&ETHERNET_SPI);

    // Get the IO descriptor for the SPI peripheral
    if (spi_m_sync_get_io_descriptor(&ETHERNET_SPI, &s_ioSPI)!=0 ) {
        return;
    };

    // Select register bank 3 (write control register 0x1F)
    // Prepare payload
    tx_buffer[0] = 0xA0|0x1F;   // Bit field clear | ECON1 register address
    tx_buffer[1] = 0x03;        // Bank 3
    // Enable the SPI slave (activates CSn)
    gpio_set_pin_level(ETHERNET_CS, 0);
    // Write payload
    io_write(s_ioSPI, tx_buffer, 2);
    // Disable the SPI slave (deactivates CSn)
    gpio_set_pin_level(ETHERNET_CS, 1);
    // Prepare payload
    tx_buffer[0] = 0x80|0x1F;   // Bit field set | ECON1 register address
    tx_buffer[1] = 0x03;        // Bank 3
    // Enable the SPI slave (activates CSn)
    gpio_set_pin_level(ETHERNET_CS, 0);
    // Write payload
    io_write(s_ioSPI, tx_buffer, 2);
    // Disable the SPI slave (deactivates CSn)
    gpio_set_pin_level(ETHERNET_CS, 1);

    // Prepare payload to put remove device from power saver mode
    tx_buffer[0] = 0xA0|0x1E;   // Bit field clear | ECON2 register address
    tx_buffer[1] = 0x20;        // PWRSV bit set
    // Enable the SPI slave (activates CSn)
    gpio_set_pin_level(ETHERNET_CS, 0);
    // Write payload
    io_write(s_ioSPI, tx_buffer, 2);
    // Disable the SPI slave (deactivates CSn)
    gpio_set_pin_level(ETHERNET_CS, 1);
}

bool _DetectEthernet() {
    struct io_descriptor *s_ioSPI;
    int8_t result = 0;
    uint8_t tx_buffer[2];
    uint8_t rx_buffer[1];

    // Get the IO descriptor for the SPI peripheral
    if (spi_m_sync_get_io_descriptor(&ETHERNET_SPI, &s_ioSPI)!=0 ) {
        return false;
    };
    // Enable the SPI peripheral
    spi_m_sync_enable(&ETHERNET_SPI);

    // Select register bank 3 (write control register 0x1F)
    // Prepare payload
    tx_buffer[0] = 0xA0|0x1F;   // Bit field clear | ECON1 register address
    tx_buffer[1] = 0x03;        // Bank 3
    // Enable the SPI slave (activates CSn)
    gpio_set_pin_level(ETHERNET_CS, 0);
    //delay_ms(1);
    // Write payload
    if (io_write(s_ioSPI, tx_buffer, 2) != 2) result = -1;
    // Disable the SPI slave (deactivates CSn)
    gpio_set_pin_level(ETHERNET_CS, 1);
    // Prepare payload
    tx_buffer[0] = 0x80|0x1F;   // Bit field set | ECON1 register address
    tx_buffer[1] = 0x03;        // Bank 3
    // Enable the SPI slave (activates CSn)
    gpio_set_pin_level(ETHERNET_CS, 0);
    //delay_ms(1);
    // Write payload
    if (io_write(s_ioSPI, tx_buffer, 2) != 2) result = -1;
    // Disable the SPI slave (deactivates CSn)
    gpio_set_pin_level(ETHERNET_CS, 1);

    // Read the Ethernet revision register
    // Prepare payload (register to read) -
    tx_buffer[0] = 0x00|0x12;   // Read control register | EREVID register address
    // Enable the SPI slave (activates CSn)
    gpio_set_pin_level(ETHERNET_CS, 0);
    // Write address of register to read - SPI
    if (io_write(s_ioSPI, tx_buffer, 1) != 1) result = -1;
    // Read register payload
    if (io_read(s_ioSPI, rx_buffer, 1) != 1)  result = -1;
    // Disable the SPI slave (deactivates CSn)
    gpio_set_pin_level(ETHERNET_CS, 1);

    // Disable the SPI peripheral
    spi_m_sync_disable(&ETHERNET_SPI);

    // Failure to write/read above indicates the device is not present
    if (result==-1) return false;
    // 0x00 or 0xFF in the REV ID register indicates that the device is not present
    else if (rx_buffer[0]==0x00 || rx_buffer[0]==0xFF) return false;
    // If we make it here, the device is present
    else return true;
}

bool Ethernet_HasLink(void) {
	return ETH_CheckLinkUp();
}